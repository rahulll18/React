import React from 'react'

const Vegmenu = ({foodItem}) => {

  let vagMenus =["Pav bhaji" , "Muttor Panner" , "Panner Masala" , "Dal Rice" ]

  const allData= vagMenus.map(vegItem => <li>{vegItem}</li>)

  const filteredData =  vagMenus.filter(vegItem => vegItem.toLowerCase().includes(foodItem)).map(vegItem=> <li>{vegItem}</li>)

  return (
    <div>
        <ul>
            {allData}
        </ul>
    </div>
  )
}

export default Vegmenu