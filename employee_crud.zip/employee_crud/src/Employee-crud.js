import axios from 'axios';

const URL = "http://localhost:5000";

export const addEmployees = async (employee)=> {
    const res = await axios.post(`${URL}/employees/add`, employee);
    return res;
}


export const getAllEmployees = async ()=> {
    const res = await axios.get(`${URL}/getEmployees`);
    return res.data;
}

export const getEmployeeById = async (_id)=> {
    const res = await axios.get(`${URL}/getEmployees/${_id}`);
    // console.log(res);
    return res.data;
}

export const deleteEmployeeId = async (_id)=> {
    const res = await axios.delete(`${URL}/delete/${_id}`);
    return res.data;
}
