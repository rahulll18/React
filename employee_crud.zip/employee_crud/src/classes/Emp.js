

export class Employee{

    constructor(
        _id=0,
        empName="", 
        deptCode="", 
        basicSalary=0, 
        experience=0, 
        emailId="",
        joiningDate=new Date()
    ){
        this._id=_id;
        this.empName=empName;
        this.deptCode=deptCode;
        this.basicSalary=basicSalary;
        this.experience=experience;
        this.emailId=emailId
        this.joiningDate=joiningDate;

    }
}