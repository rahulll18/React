import React from 'react'
import Emploeecard from './Emploeecard'

const Maincard = () => {
    const employees = [
        {
            employecode:12742,
            name:"Rahul Avhad",
            department:"Software Development",
            bloodGroup : "B+ve"
        },
        {
            employecode:12743,
            name:"Hardik Jain",
            department:"IT",
            bloodGroup : "O+ve"
        },
        {
            employecode:12744,
            name:"Krishna Sharma",
            department:"Sales",
            bloodGroup : "AB+ve"
        },
        {
            employecode:12745,
            name:"Saurabh Jagtap",
            department:"Talent Acquisition",
            bloodGroup : "A+ve"
        }
    ]
    

  return (
    <div className='flex flex-wrap'>
        {
            employees.map((employee,index) => <Emploeecard key={index} employee={employee} />)
        }
    </div>
  )
}

export default Maincard