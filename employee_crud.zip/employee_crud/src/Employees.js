import { useState } from "react";
import { EmployeeCard } from "./Empcard";
import { Employee } from "./classes/Emp";
import { useEffect } from "react";
import { getAllEmployees } from "./Employee-crud";

export function Employees() {
  let [neoemployees, setNeoEmployees] = useState([
    new Employee(123, "Hari Kumar", "LD", 90000, 20, new Date("12 Jan 2002")),
    new Employee(121, "Pari Kumari", "JS", 95000, 25, new Date("12 Dec 2000")),
  ]);

  const getEmp = async () => {
    const data = await getAllEmployees();
    setNeoEmployees(data);
  };

  useEffect(() => {
    console.log("in useEffect");
    getEmp();
  }, []);

  let cards = neoemployees.map((employee) => (
    <EmployeeCard
      key={employee._id}
      employee={employee}
      getEmp={getEmp}
    ></EmployeeCard>
  ));

  return (
    <section className="d-flex flex-wrap w-[95%] mx-auto z-0 mt-16 p-4 ">
      {cards}
    </section>
  );
}
