
import './header.css'
import Navbar from "../navbar/Navbar.js";


const Header = ()=>{

    return(
        <div className='header fixed top-0 w-full z-10'>
            <Navbar/>
        </div>    
      
    )
}
export default Header;