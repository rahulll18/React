import React, { useEffect, useRef, useState } from 'react'

const Hooks = () => {
    let num = 5;
    const [stateCounter , setstateCounter] = useState(0);
    const refCounter = useRef(0);

    useEffect(()=>{
        console.log("use effect called");
        console.log(num);
        console.log(stateCounter);
        console.log(refCounter);
    },[stateCounter,refCounter ,num])
  return (
    <div>
        <div>
            <b>Counter is : {num}</b>
            <button className='p-1 ml-4 border border-black' onClick={()=>num = num+1}>Increment normal counter</button>
        </div>
        <div>
            <b>Counter is : {stateCounter}</b>
            <button className='p-1 ml-4 border border-black' onClick={()=>setstateCounter(stateCounter+1)}>Increment state counter</button>
        </div>
        <div>
            <b>Counter is : {refCounter.current}</b>
            <button className='p-1 ml-4 border border-black' onClick={()=> refCounter.current = refCounter.current+1}>Increment ref counter</button>

        </div>
    </div>
  )
}

export default Hooks