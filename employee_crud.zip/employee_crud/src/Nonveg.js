import React from 'react'

const Nonveg = () => {
  return (
    <div>
        <ul>
            <li>Chicken gravy</li>
            <li>Chicken Lolypop</li>
            <li>Chicken Biryani</li>
            <li>Egg cury</li>
        </ul>
    </div>
  )
}

export default Nonveg