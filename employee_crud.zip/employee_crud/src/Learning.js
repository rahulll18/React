import {useEffect, useRef, useState} from 'react'

const Learning = ()=>{
    const [sum, setSum] = useState(0)
    const [subtract, setSubtract] = useState(0)
    const [buttonStyle , changeButtonstyle] = useState({
        backgroundColor :"blue",
        padding : "10px"
    })
    let ageNode = useRef();
    let[age , setAge] = useState(0);


    let add = (...args)=>{
        let result = args.reduce((acc ,ele)=> acc+ele)
        setSum(result);
    };

    let minus = (...args)=>{
        let result = args.reduce((acc ,ele)=> acc - ele)
        setSubtract(result);
    };

    //case 1 : dependency array , case 2: state variable in dependency array
    useEffect(()=>{
        console.log("Useeffect Called");
        console.log("connect activity");
        
        return ()=>{
            console.log("clean up activity")
        }
    },[sum])
    
    let change= ()=>{
        let newStyle = {...buttonStyle , backgroundColor:"pink" , borderRadius : "30px"};
        changeButtonstyle(newStyle)
    }
    
    return(
        <>
         <div>
            <button type='button' onClick={()=>add(2,4,6,8)}>Add</button>
            <p>Sum is :- {sum}</p>
        </div>
         <div>
            <button type='button' className={buttonStyle} onClick={change}>hello</button>
        </div>
       <div>
            <h2>If else Show and hidden</h2>

            <input type='number' ref={ageNode} defaultValue="0" onKeyUp={()=>setAge(ageNode.current.value)} />
            {
                age >= 18 
                ?
                <p>You are allowed </p>
                :
                <p>You are not allowed for voting </p>

            }
         </div>
        </>
       
    )
}

export default Learning;