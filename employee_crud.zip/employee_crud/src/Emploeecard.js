import React from 'react'
import employeeImg from './employee_profile.jpg'


const Emploeecard = ({employee}) => {
  const{employecode , name , department ,bloodGroup} = employee;
  return (
    <div className='transition-transform delay-200 duration-1000 hover:rotate-[360deg] flex flex-col items-center border border-black max-w-72 mx-auto rounded-lg'>
        <div className='flex justify-center text-2xl my-3'>
        <div className='font-bold'>Neo</div><span className='text-red-600 font-bold '>SOFT</span>
        </div>
        <img src={employeeImg} alt='emp-card' className='w-32 border border-gray-400 rounded-2xl'/>
        <div className='text-red-500 text-lg font-semibold mt-2'>{name}</div>
        <div className='text-black text-lg font-semibold '>{department}</div>
        <div className='mt-1 text-sm'>{employecode}</div>
        <div className='text-sm'>{bloodGroup}</div>
        <div className='text-white text-sm text-center p-3 bg-red-500'>The Ruby Tower,Unit no. 5,4th Floor,29 Senapati Bapat Marg,Dadar(W),Mumbai - 400 028, Maharashtra , India. Phone: 022-40500600</div>
        <div className='text-black font-semibold font-mono text-sm'>www.neosofttech.com</div>
    </div>
  
  )
}

export default Emploeecard