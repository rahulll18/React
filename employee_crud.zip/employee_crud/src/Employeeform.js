import { useEffect, useState } from "react";
import { Employee } from "./classes/Emp";
import { useParams } from "react-router-dom";
import { addEmployees , getEmployeeById} from "./Employee-crud";

export function EmployeeForm() {
  let { empId } = useParams();
  console.log(empId)

  let [employee, setEmployee] = useState(new Employee());

  function getData(ev) {
    setEmployee({ ...employee, [ev.target.id]: ev.target.value });
  }

  async function getEmp(){
    if(empId!==undefined){
        let emp=await getEmployeeById(empId);
        // console.log(emp);
        emp.joiningDate=emp.joiningDate.slice(0, emp.joiningDate.length-2);
        // console.log(emp)
        setEmployee(emp);
    }
}

  function collectData(ev) {
    ev.preventDefault();

    if (empId !== undefined) console.log("updateemp");
    else {
        addEmp();
    }
  }

  async function addEmp() {
    console.log(employee)
    const res = await addEmployees(employee);
    if(res!= null){
        window.alert("Employee added sunccessfully");
    }else{
        window.alert("Error while adding Employee !!");
    } 
 }

  useEffect(() => {
    getEmp();
  },[]);

  let departmentCodes = ["JS", "LD", "PHP", "HR", "DN"];
  let options = departmentCodes.map((dcode, i) => (
    <option key={"o" + i}>{dcode}</option>
  ));
  return (
    <article className="d-flex justify-content-center z-0">
      <div className="p-3 border border-3 w-50">
        <h3>EMPLOYEE INPUT FORM</h3>
        <form onSubmit={collectData}>
          <div className="mb-3">
            <label htmlFor="empId" className="form-label">
              ID
            </label>
            <input
              type="number"
              className="form-control"
              id="_id"
              name="empId"
              value={employee._id}
              onChange={getData}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="empName" className="form-label">
              NAME
            </label>
            <input
              type="text"
              className="form-control"
              id="empName"
              value={employee.empName}
              onChange={getData}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="emailId" className="form-label">
              EMAIL ID
            </label>
            <input
              type="email"
              className="form-control"
              id="emailId"
              value={employee.emailId}
              onChange={getData}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="basicSalary" className="form-label">
              BASIC SALARY
            </label>
            <input
              type="number"
              className="form-control"
              id="basicSalary"
              value={employee.basicSalary}
              onChange={getData}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="experience" className="form-label">
              EXPERIENCE
            </label>
            <input
              type="number"
              className="form-control"
              id="experience"
              value={employee.experience}
              onChange={getData}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="joiningDate" className="form-label">
              JOINING DATE
            </label>
            <input
              type="datetime-local"
              className="form-control"
              id="joiningDate"
              value={employee.joiningDate}
              onChange={getData}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="deptCode" className="form-label">
              SELECT DEPARTMENT
            </label>
            <select id="deptCode" value={employee.deptCode} onChange={getData}>
              {options}
            </select>
          </div>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    </article>
  );
}
