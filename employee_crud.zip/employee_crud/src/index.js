import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { createBrowserRouter, redirect, RouterProvider } from 'react-router-dom';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../node_modules/bootstrap/dist/js/bootstrap.bundle"
import Maincard from "./Maincard"
import { EmployeeForm } from './Employeeform';
import Home from './Home';
import { Employees } from './Employees';


export let MyContext= React.createContext();

let childRoutes=[
  {
    path : '',
    element :<Home />
  },
  {
    path:'employees',
    element:<Employees />
  },
  {
    path:'employeeform',
    element:<EmployeeForm></EmployeeForm>
  },
  {
    path:'editEmployee/:empId',
    element:<EmployeeForm></EmployeeForm>
  }
  
]

const router= createBrowserRouter([
  {
    path:'/',
    element:<App></App>,
    children:childRoutes
  }
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} ></RouterProvider >
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
