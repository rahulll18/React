import { Link } from 'react-router-dom';
import employeeImg from './employee_profile.jpg'
import {deleteEmployeeId} from './Employee-crud';

export function EmployeeCard({employee ,getEmp}){

    async function deleteEmployee(_id){
        
        const ans=window.confirm("Do you really want to delete??")
        if(ans) {
            const data=await deleteEmployeeId(_id);
            if(data.deletedCount>0){
                window.alert("Employee deleted Successfully")
                getEmp();
            }
            else
                window.alert("Something went wrong....")
        }
    }

    return(
        <div className="card z-0 h-full m-2" style={{width: '18rem'}}>
            <img height="150" src={employeeImg} className="card-img-top" alt="..." />
            <div className="card-body">
                <h6>#{employee._id}</h6>
                <h5 className="card-title">{employee.empName}</h5>
                <p className="card-text"> {employee.empName} joined on {employee.joiningDate.toString()}</p>
                </div>
                <ul className="list-group list-group-flush">
                <li className="list-group-item">Department : {employee.deptCode}</li>
                <li className="list-group-item">Basic Salary : {employee.basicSalary}</li>
                <li className="list-group-item">Experience : {employee.experience} years</li>
                </ul>
                <div className="card-body">
                <Link to={`/editEmployee/${employee._id}`} className="card-link">EDIT</Link>
                <button onClick={()=>deleteEmployee(employee._id)} className="card-link">DELETE</button>
            </div>
        </div>
    );
}