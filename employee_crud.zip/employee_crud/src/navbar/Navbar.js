import { useState } from "react";

const Navbar = ()=>{
    const [issignIn , setSignIn] = useState(true)

    return(
      <nav class="w-full p-2 flex justify-around items-center shadow-lg bg-white shadow-gray-500 z-10">
        <div className="font-semibold">Navbar</div>
        <div className="text-blue-600 font-bold text-xl">Employee CRUD</div>
        <button className="text-black border-2 rounded-md border-blue-600 px-3 py-2 hover:bg-" onClick={()=> setSignIn(!issignIn)}>
          {
            issignIn ? "Sign In" : "Sign Out"
          }
          </button>
      </nav>
    );
}

export default Navbar; 