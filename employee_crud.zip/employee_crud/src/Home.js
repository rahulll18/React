import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <div className='flex justify-center items-center h-[90vh]'>
        <div className=' w-[40%] h-[200px] flex flex-col items-center justify-evenly rounded-lg shadow-inner shadow-blue-600'>
            <h1 className='text-4xl font-extrabold '>Employee CRUD <span className='text-blue-600'>Application</span></h1>
            <div className='text-center font-medium mt-3'>The platform where you can perform Create , Read , Update , Delete operations</div>
            <Link to='/employees'><button className='mt-3 px-4 py-2 border-2 border-blue-600'>See All Employees <i class="ri-arrow-right-line ml-2"></i></button></Link>
        </div>
    </div>
  )
}

export default Home