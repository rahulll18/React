import { useRef, useState } from "react"
import Nonveg from "./Nonveg"
import Vegmenu from "./Vegmenu"

const Menu = ()=>{
    const[option , setOption] = useState("veg");
    const[serachItem , setSearchItem] = useState("");

    let inputNode = useRef();
    function handleChange(e){
        setOption(e.target.value);
    }
    
    return(
        <>
        <input placeholder="Search the food item" ref={inputNode} onKeyUp={()=>setSearchItem(inputNode.current.value)} className="border border-black"/>

        <select value={option}  onChange={handleChange} name="menus" >
            <option value="veg" >Veg</option>
            <option value="non-veg" >Non-veg</option>
            <option value="both" >Both</option>
        </select>  
            {
                option === "veg" || option === "both" ? <Vegmenu foodItem={serachItem} /> : null }
            {
                option === "non-veg" || option === "both" ? <Nonveg foodItem={serachItem} /> : null
            }
        </>
    )
}
export default Menu